const singleOrder = document.querySelector(".single-order");
const orderId = document.getElementById("order-id");
console.log(orderId);
if (orderId) {
  orderId.addEventListener("click", () => {
    console.log("working");
  });
}
