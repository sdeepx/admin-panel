const orderTable = document.querySelector(".order-table");
const loading = (is_loading) => {
  if (is_loading) {
    orderTable.innerHTML = `
                   <p class="text-center m-4">
                          <div class="spinner-grow text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                          </div>
                          <div class="spinner-grow text-secondary" role="status">
                            <span class="visually-hidden">Loading...</span>
                          </div>
                          <div class="spinner-grow text-success" role="status">
                            <span class="visually-hidden">Loading...</span>
                          </div>
                          <div class="spinner-grow text-danger" role="status">
                            <span class="visually-hidden">Loading...</span>
                          </div>
                      </p>
`;
  } else {
    orderTable.innerHTML = "";
  }
};

const getOrders = (datas) => {
  loading(false);
  const orders = datas.orders;
  // const showOrder = orders.length / 2;
  let i = 0;

  while (i < 10) {
    orderTable.innerHTML += `<tr>
                              <td><a onclick=getSingleOrder(${orders[i]["id"]}) class="order-id">${orders[i]["id"]}</a></td>
                              <td>${orders[i]["prod_name"]}</td>
                              <td>${orders[i]["max_selling_amount"]} ₹</td>
                              <td>${orders[i]["total_deduction"]} ₹</td>
                              <td>${orders[i]["final_cost"]} ₹</td>
                              <td>${orders[i]["created_by_user_id"]}</td>
                              <td>${orders[i]["cont_name"]}</td>
                            </tr>`;
    i++;
  }
};

window.onload = () => {
  loading(true);
  const url = "https://sold.sayantanbasu.in/action/order/action_get_orders.php";
  fetch(url, { method: "GET" })
    .then((res) => res.json())
    .then((datas) => getOrders(datas))
    .catch((err) => console.log(err));
};

// get single order on same page

const showSingleOrder = (datas) => {
  if (datas.status === "2") {
    document
      .querySelector(".single-order-container")
      .classList.remove("d-none");
    const singleOrder = document.querySelector(".single-order");
    const singleAddress = document.querySelector(".single-address");
    const singleProblem = document.querySelector(".single-problem");

    const order = datas.order;
    const address = datas.order.address;
    const problem = datas.order.problem;

    singleOrder.innerHTML = "";
    singleAddress.innerHTML = "";
    singleProblem.innerHTML = "";

    for (const i in order) {
      if (i !== "address" && i !== "problem") {
        singleOrder.innerHTML += `
                      <p>${i}: <span class="text-center text-primary"> ${order[i]} </span> </p>
        `;
      }
    }
    for (const i in address) {
      singleAddress.innerHTML += `
                      <p>${i}: <span class="text-center text-primary"> ${address[i]} </span> </p>
        `;
    }
    for (const i in problem) {
      singleProblem.innerHTML += `<hr>`
      for (const j in problem[i]) {
        singleProblem.innerHTML += `
                      <p>${j}: <span class="text-center text-primary"> ${problem[i][j]} </span> </p>
        `;
      }
    }
    window.scrollTo(0, document.body.scrollHeight);
  }
};

function getSingleOrder(id) {
  const url = "https://sold.sayantanbasu.in/action/order/action_get_order.php";
  fetch(`${url}?order_id=${id}`, { method: "GET" })
    .then((res) => res.json())
    .then((datas) => showSingleOrder(datas))
    .catch((err) => console.log(err));
}
