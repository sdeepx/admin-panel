<section class="mb-4">
      <div class="card">
            <div class="card-header text-center py-3">
                  <h5 class="mb-0 text-center">
                        <strong>All Orders</strong>
                  </h5>
            </div>
            <div class="card-body">
                  <div class="table-responsive">
                        <table class="table table-hover text-nowrap">
                              <thead>
                                    <tr>
                                          <th scope="col">Order Id</th>
                                          <th scope="col">Product Name</th>
                                          <th scope="col">Max Selling Amount</th>
                                          <th scope="col">Total Deduction</th>
                                          <th scope="col">Final Cost</th>
                                          <th scope="col">User Id</th>
                                          <th scope="col">User Name</th>
                                    </tr>
                              </thead>
                              <tbody class="order-table">

                              </tbody>
                        </table>
                  </div>
            </div>
      </div>
</section>
<!--orders-->
