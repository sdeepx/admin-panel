<?php
ob_start();
include_once("is_logedin.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" />
      <!-- MDB -->
      <link rel="stylesheet" href="./../dashboard/css/mdb.min.css" />
      <link rel="stylesheet" href="./../dashboard/css/admin.min.css" />
      <title>Dashboard</title>
</head>

<body>
      <header>
            <!-- Sidebar -->
            <nav id="sidebarMenu" class="collapse d-lg-block sidebar collapse bg-white">
                  <div class="position-sticky">
                        <div class="list-group list-group-flush mx-3 mt-4">
                              <a href="/dashboard" class="list-group-item list-group-item-action py-2 ripple" aria-current="true">
                                    <i class="fas fa-tachometer-alt fa-fw me-3"></i><span>Main dashboard</span>
                              </a>
                              <a href="<?php echo htmlspecialchars("?page=orders");  ?>" class="list-group-item list-group-item-action py-2 ripple" aria-current="true">
                                    <i class="fas fa-shopping-cart me-3"></i><span>Orders</span>
                              </a>
                        </div>
                  </div>
            </nav>
            <!-- Sidebar -->

            <nav id="main-navbar" class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
                  <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
                              <i class="fas fa-bars"></i>
                        </button>


                        <form class="d-none d-md-flex input-group w-auto my-auto">
                              <input autocomplete="off" type="search" class="form-control rounded" placeholder='Enter product id' style="min-width: 235px" />
                              <span class="input-group-text text-primary border-0"><i class="fas fa-search"></i></span>
                        </form>

                        <ul class="navbar-nav ms-auto d-flex flex-row">

                              <li class="nav-item mt-1 me-3 me-lg-0">
                                    Welcome
                                    <?php
                                    echo $_COOKIE["user_name"];
                                    ?> &nbsp; &nbsp;
                              </li>


                              <!-- Avatar -->
                              <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle hidden-arrow d-flex align-items-center text-primary" href="#" id="navbarDropdownMenuLink" role="button" data-mdb-toggle="dropdown" aria-expanded="false">
                                          <i class="fas fa-user"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                                          <li><a class="dropdown-item" href="#">My profile</a></li>
                                          <li><a class="dropdown-item" href="#">Logout</a></li>
                                    </ul>
                              </li>
                        </ul>
                  </div>
            </nav>
            <!-- Navbar -->
      </header>

      <!--Main layout-->
      <main class="mt-5">

            <div class="container pt-4">

                  <?php
                  if (!empty($_GET["page"])) {
                        $page = $_GET["page"];
                        $dir = "pages";
                        $file = scandir($dir, 0);
                        unset($file[0]);
                        if (in_array($page . ".php", $file)) {
                              include($dir . "/" . $page . ".php");
                        }
                  } else {
                        include("main.php");
                  }
                  ?>

            </div>
      </main>


      <script type="text/javascript" src="./../dashboard/js/mdb.min.js"></script>
      <script type="text/javascript" src="./../dashboard/js/app.min.js"></script>

</body>

</html>