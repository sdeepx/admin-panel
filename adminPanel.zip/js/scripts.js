const form = document.querySelector("form");
const btn = document.querySelector(".btn");

const hideAlert = () => {
  const el = document.querySelector(".alert");
  if (el) el.parentElement.removeChild(el);
};

const showAlert = (type, message) => {
  hideAlert();
  const showalert = `
                    <div class="alert text-center alert-${type}" role="alert">
                    <strong>${message}!</strong>
                    </div>`;

  form.insertAdjacentHTML("beforeend", showalert);
  setTimeout(hideAlert, 15000);
};

const btnClicked = (is_clicked) => {
  if (is_clicked) {
    hideAlert();
    btn.classList.remove("btn-primary");
    btn.classList.add("btnClicked");
    btn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status">
                  </span> Loging in...`;
    btn.setAttribute("disabled", "disabled");
  } else {
    btn.removeAttribute("disabled");
    btn.classList.add("btn-primary");
    btn.classList.remove("btnClicked");
    btn.innerText = `Log In`;
  }
};

const logIn = (data) => {
  btnClicked(false);

  switch (data.status) {
    case "0":
      showAlert("danger", data.message);
      break;

    case "1":
      showAlert("warning", data.message);
      break;

    case "7":
      showAlert("success", data.message);
      for (const i in data.user) {
        if (i !== "password") {
          document.cookie = `${escape(i)}=${escape(data.user[i])}`;
        }
      }
      setTimeout(() => {
        window.location.href = "/dashboard";
      }, 1000);
      break;

    default:
      break;
  }
};

const reqRes = (fd, url) => {
  fetch(url, {
    method: "POST",
    body: fd,
  })
    .then((res) => res.json())
    .then((data) => logIn(data))
    .catch((err) => showAlert("danger", "Something went wrong!"));
};

if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    btnClicked(true);
    const url = "https://sold.sayantanbasu.in/action/login/action_login.php";
    const fd = new FormData(e.target);
    reqRes(fd, url);
  });
}
